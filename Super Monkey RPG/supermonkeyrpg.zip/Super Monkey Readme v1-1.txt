
	        Super Monkey RPG v1.1
		    FINAL VERSION
	=====================================
	  by ChiefMonkey (askmark@mail.com)
	=====================================
		        5/18/01


========
CONTENTS
========
I.   General
II.  Glitches and all that Other Shit
III. Things That Are Different/Future Changes
IV.  What Isn't Different
V.   Thanks to...
VI.  Don't get some of the Jokes?

I.   General

	This .ips patch changes the game to make it appeal to a more
	mature audience. There IS adult language, verbal abuse, drug
	abuse (Frogfucius and Mushroom Boy), and several jokes about
	Eminem being well... a gay little pussy.
	Fuck those "Spoof" SNES hacks. This game has more balls than
	all the others combined. So watch the fuck out.
	Comparison-> CTSpoof.ips=2.9 KB, Super Monkey RPG.ips = 103 KB!
	I've played through the game a little at a time, changing
	text, and reloading states, playing each section over and
	over till it's good. Then I played through it one full time.
	I even played a lot of the cartridge on my SNES. I analyzed
	every fucking byte! This is a 3-month full complete project!
	TRY TO DO EVERYTHING! EVERYTHING IS CHANGED! Save a state
	right before you have a choice so you can see every combination!
        MY TOADOFSKY SONG ENDING---> GABCEGDB (Try it, it sounds nice!)

II.  Glitches and all that Other Shit

	Sometimes when you first enter a room or even when
	you talk to someone, you'll disappear! David motherfuckin'
	Copperfield style! I don't know why and it always happens
	after I load a state. Also sometimes (2 or 3 times I've found)
	the text engine will repeat a sentence for one reason or
	another. The characters will make fun of the glitch
	themselves so you'll know. "Did I just say the same shit
	twice? Must be a glitch!"

III. Things That Are Different

	VERSION 1.1-FINAL (5/18/01)
	-----------
	- Changed all text including (but not limited to):
	  - All instructions for every game (ok, not Blackjack)
	  - Grate Guy's Casino
	  - Every Frogfucius message
	  - Enemy names
	  - The Gardener
	  - Snifit #4
	  - The PLOT ALTOGETHER
	  - The game's header itself
	  - All 6 games in Sunken Ship
	  - The Dojo (winning, losing, and running away)
	  - Culex
	  - Yo'ster Isle
	  - The new messages you get when you save a city
	  - Leaving Marrymore the wrong way after saving Peach
	  - The 2 guys hidden behind buildings & all their messages
	  - Fighting and NOT FIGHTING Booster
	- If you have Version 1.0, play this from START. Some of the
	  beginning things have been rechanged and are even funnier!
	- If you haven't played Super Mario RPG the ORIGINAL way made
	  by Nintendo, play it that way first or you won't know what
	  to do in this one.  Also, don't play this AT ALL if you
	  don't have the original SNES cartridge!
	  It's illegal (I think)!

	VERSION 1.0 (4/6/01)
	-----------
	- Initial release. Pretty much a demo.
	- There's a good chance you didn't even know there was
	  a release before 1.1! It was only available for a week.
	- "Floyd" is in the game. Unless you are NinjaChipmunk,
	  you have no idea what this means. This is for personal
	  humor.  Inside joke...
	- All text up through the first time you talk to the
	  chancellor, including everyone in the mushroom kingdom.
	  Plus much more text later in the game.

IV.   What ISN'T Changed

	The Psychopath enemy thoughts.
	Graphics

V.    Thanks to...

	First, Scott Babin for the motivation to keep hacking.
	(Thanks for making a scrub like me feel famous!)
	Angela, Honey, Josh, RJ, Brandi, Alex, Ray for bein' down.
	NinjaChipmunk for playtesting and ideas! Visit his site!
	     --> http://ninjachipmunk.tripod.com <--
	Jazz411@epix.net for ideas & support. Play his hacks, y'all!
	http://smb3c.darkmazda.com/showcase for posting all
	 of my hacks and all of NinjaChipmunk's too!
	The Dark Carnival and the 6 Joker's Cards for influence.
	Waffle House for not arresting me when I stab people there. Whut!

VI.   Don't get some of the Jokes?

	Neden = Juggalo slang for female genitalia.
	Ninja = Buddy, Chief, Bro, dog, man, dude, etc.
	Faygo = The poor man's soda. Juggalo-Juice.
	Juggalo = If you don't know what it mean, you ain't one.
	Fakoof= Unofficial spelling of "Fuck Off" in a high-pitched voice.
	Anything Culex Says = Watch "Monty Python & the Holy Grail"
	Eminem Jokes = There are probably like 50 Eminem disses in this game.
	 If you are a little "wannabe gangbanger" and LIKE Eminem, don't even
	 play this shit. Go play "Which orifice can I stick my thumb in?"
	 like you were doing before you downloaded this.


If this game was a movie, it'd be rated R.
If the ESRB rated it, it'd be AO.
If it was on TV, it'd be rated TVMA-DSLV.
If this game was a music video, MTV wouldn't play it.

That text file only Treehouse Members can read?
The password to open is the Website username.
The username? Beat the game and you just might get it!

Contact ChiefMonkey, good or bad.
askmark@mail.com
http://master_ofpuppets.tripod.com